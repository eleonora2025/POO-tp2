package ar.org.centro8.java.curso.tp2.entidades;

import lombok.Getter;
import lombok.Setter;
import java.text.DecimalFormat;

@Getter
@Setter
public class Auto extends Vehiculo {
    private int puertas;

    public Auto(String marca, String modelo, double precio, int puertas) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    @Override
    public String toString() {
        DecimalFormat df = new DecimalFormat("$#,##0.00");
        return String.format(
                "Marca: " + getMarca() + " // Modelo: " + getModelo() + " // Puertas: " + puertas + " // Precio: " +
                        df.format(getPrecio()));
    }

}
