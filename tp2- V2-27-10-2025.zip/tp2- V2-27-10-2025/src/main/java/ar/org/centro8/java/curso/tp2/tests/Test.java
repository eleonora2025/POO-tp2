﻿package ar.org.centro8.java.curso.tp2.tests;

import ar.org.centro8.java.curso.tp2.entidades.Auto;
import ar.org.centro8.java.curso.tp2.entidades.Moto;
import ar.org.centro8.java.curso.tp2.entidades.Vehiculo;
import ar.org.centro8.java.curso.tp2.interfaces.*;

public class Test {
   public static void main(String[] args) {

      Implementacion listaVehiculo = new Implementacion();
      Vehiculo auto1 = new Auto("Peugeot", "206", 200000, 4);
      Vehiculo moto1 = new Moto("Honda", "Titan", 60000, 125);
      Vehiculo auto2 = new Auto("Peugeot", "208", 250000, 5);
      Vehiculo moto2 = new Moto("Yamaha", "YBR", 80500.50, 160);

      listaVehiculo.agregarVehiculos(auto1, moto1, auto2, moto2);
      listaVehiculo.imprimirVehiculos();
      listaVehiculo.vehiculoMasCaro();
      listaVehiculo.vehiculoMasBarato();
      listaVehiculo.vehiculoPorLetra("y");
      listaVehiculo.vehiculosPorPrecioDescendente();
      listaVehiculo.vehiculosPorOrdenNatural();
   }
}
