package ar.org.centro8.java.curso.tp2.entidades;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public abstract class Vehiculo implements Comparable<Vehiculo> {
    private String marca;
    private String modelo;
    private double precio;

    /**
     * Comparación: Compara las marcas de los dos vehículos, sin importar mayúsculas
     * o minúsculas.
     * Devuelve: 0 si las marcas son iguales.
     * Un número negativo si this.marca es “menor” (alfabéticamente antes).
     * Un número positivo si this.marca es “mayor” (alfabéticamente después).
     * Si las marcas son iguales (alfabéticamente), se pasa a comparar los modelos.
     * Y por último, compara los precios
     * 
     * @param vehiculo2: Vehículo a comparar
     * @return comparación: resultado de la comparación
     */

    @Override
    public int compareTo(Vehiculo vehiculo2) {
        int comparacion = this.marca.compareToIgnoreCase(vehiculo2.marca);
        if (comparacion == 0) {
            comparacion = this.modelo.compareToIgnoreCase(vehiculo2.modelo);
            if (comparacion == 0) {
                return Double.compare(this.precio, vehiculo2.precio);
            }
        }
        return comparacion;
    }

}
